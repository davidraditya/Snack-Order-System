--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.4
-- Dumped by pg_dump version 9.6.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.terdiri_dari DROP CONSTRAINT terdiri_dari_order_id_fkey;
ALTER TABLE ONLY public.melakukan DROP CONSTRAINT melakukan_order_id_fkey;
ALTER TABLE ONLY public.diantar DROP CONSTRAINT diantar_order_id_fkey;
ALTER TABLE ONLY public.produk DROP CONSTRAINT produk_pkey;
ALTER TABLE ONLY public.pengantar DROP CONSTRAINT pengantar_pkey;
ALTER TABLE ONLY public.pembeli DROP CONSTRAINT pembeli_pkey;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_pkey;
ALTER TABLE ONLY public.login DROP CONSTRAINT login_pkey;
ALTER TABLE public.produk ALTER COLUMN produk_id DROP DEFAULT;
ALTER TABLE public.orders ALTER COLUMN order_id DROP DEFAULT;
DROP TABLE public.terdiri_dari;
DROP SEQUENCE public.produk_produk_id_seq;
DROP TABLE public.produk;
DROP TABLE public.pengantar;
DROP TABLE public.pembeli;
DROP SEQUENCE public.orders_order_id_seq;
DROP TABLE public.orders;
DROP TABLE public.melakukan;
DROP TABLE public.login;
DROP TABLE public.diantar;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: diantar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE diantar (
    pengantar_no_hp text,
    order_id integer
);


ALTER TABLE diantar OWNER TO postgres;

--
-- Name: login; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE login (
    username text NOT NULL,
    password text
);


ALTER TABLE login OWNER TO postgres;

--
-- Name: melakukan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE melakukan (
    pembeli_no_hp text,
    order_id integer
);


ALTER TABLE melakukan OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders (
    order_id integer NOT NULL,
    total integer,
    tempat text NOT NULL,
    tanggal date,
    waktu time without time zone
);


ALTER TABLE orders OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE orders_order_id_seq OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE orders_order_id_seq OWNED BY orders.order_id;


--
-- Name: pembeli; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembeli (
    no_hp text NOT NULL,
    nama character varying(50) NOT NULL,
    fakultas text NOT NULL,
    prodi text
);


ALTER TABLE pembeli OWNER TO postgres;

--
-- Name: pengantar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pengantar (
    nama character varying(50),
    no_hp text NOT NULL
);


ALTER TABLE pengantar OWNER TO postgres;

--
-- Name: produk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE produk (
    produk_id integer NOT NULL,
    nama text,
    harga integer
);


ALTER TABLE produk OWNER TO postgres;

--
-- Name: produk_produk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE produk_produk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE produk_produk_id_seq OWNER TO postgres;

--
-- Name: produk_produk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE produk_produk_id_seq OWNED BY produk.produk_id;


--
-- Name: terdiri_dari; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE terdiri_dari (
    order_id integer,
    produk_id integer,
    kuantitas integer
);


ALTER TABLE terdiri_dari OWNER TO postgres;

--
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders ALTER COLUMN order_id SET DEFAULT nextval('orders_order_id_seq'::regclass);


--
-- Name: produk produk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produk ALTER COLUMN produk_id SET DEFAULT nextval('produk_produk_id_seq'::regclass);


--
-- Data for Name: diantar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY diantar (pengantar_no_hp, order_id) FROM stdin;
\.
COPY diantar (pengantar_no_hp, order_id) FROM '$$PATH$$/2177.dat';

--
-- Data for Name: login; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY login (username, password) FROM stdin;
\.
COPY login (username, password) FROM '$$PATH$$/2174.dat';

--
-- Data for Name: melakukan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY melakukan (pembeli_no_hp, order_id) FROM stdin;
\.
COPY melakukan (pembeli_no_hp, order_id) FROM '$$PATH$$/2178.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (order_id, total, tempat, tanggal, waktu) FROM stdin;
\.
COPY orders (order_id, total, tempat, tanggal, waktu) FROM '$$PATH$$/2176.dat';

--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('orders_order_id_seq', 34, true);


--
-- Data for Name: pembeli; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembeli (no_hp, nama, fakultas, prodi) FROM stdin;
\.
COPY pembeli (no_hp, nama, fakultas, prodi) FROM '$$PATH$$/2170.dat';

--
-- Data for Name: pengantar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pengantar (nama, no_hp) FROM stdin;
\.
COPY pengantar (nama, no_hp) FROM '$$PATH$$/2171.dat';

--
-- Data for Name: produk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY produk (produk_id, nama, harga) FROM stdin;
\.
COPY produk (produk_id, nama, harga) FROM '$$PATH$$/2173.dat';

--
-- Name: produk_produk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('produk_produk_id_seq', 9, false);


--
-- Data for Name: terdiri_dari; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY terdiri_dari (order_id, produk_id, kuantitas) FROM stdin;
\.
COPY terdiri_dari (order_id, produk_id, kuantitas) FROM '$$PATH$$/2179.dat';

--
-- Name: login login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY login
    ADD CONSTRAINT login_pkey PRIMARY KEY (username);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: pembeli pembeli_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembeli
    ADD CONSTRAINT pembeli_pkey PRIMARY KEY (no_hp);


--
-- Name: pengantar pengantar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pengantar
    ADD CONSTRAINT pengantar_pkey PRIMARY KEY (no_hp);


--
-- Name: produk produk_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produk
    ADD CONSTRAINT produk_pkey PRIMARY KEY (produk_id);


--
-- Name: diantar diantar_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY diantar
    ADD CONSTRAINT diantar_order_id_fkey FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE;


--
-- Name: melakukan melakukan_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY melakukan
    ADD CONSTRAINT melakukan_order_id_fkey FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE;


--
-- Name: terdiri_dari terdiri_dari_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY terdiri_dari
    ADD CONSTRAINT terdiri_dari_order_id_fkey FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

